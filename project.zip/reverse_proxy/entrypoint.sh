#!/bin/sh
sleep 30
nginx -g 'daemon off;'